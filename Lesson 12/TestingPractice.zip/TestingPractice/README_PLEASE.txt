Hello!

I was able to get Eclipse to work and have installed Spring and JUnit on there.

I didn't, however, complete the HLT successfully as I could not figure out which parts of my text based game would need testing. As far as I could gather, you want to test things that have return units, but I didn't have any in there and couldn't figure it out.

Instead, as I wanted to be able to show something, I created a new java guess the number game to test instead, as I could see it more clearly if I was working from scratch (and building in testing opportunities from the start), and have included that. I hope that's okay?